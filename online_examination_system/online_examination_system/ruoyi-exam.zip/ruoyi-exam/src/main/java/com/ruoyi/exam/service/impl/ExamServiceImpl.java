package com.ruoyi.exam.service.impl;

import com.ruoyi.exam.domain.ExamSubmission;
import com.ruoyi.exam.domain.Question;
import com.ruoyi.exam.mapper.QuestionMapper;
import com.ruoyi.exam.service.ExamService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class ExamServiceImpl implements ExamService {
    @Autowired
    private QuestionMapper questionMapper;

    @Override
    public int calculateScore(ExamSubmission submission) {
        // 提取所有问题的ID
        List<Long> questionIds = submission.getAnswers().stream()
                .map(ExamSubmission.Answer::getQuestionId)
                .collect(Collectors.toList());

        // 一次性查询所有问题
        List<Question> questions = questionMapper.getBySubjectIds(submission.getSubjectIds());

        // 将问题列表转换为Map，便于快速查找
        Map<Long, Question> questionMap = questions.stream()
                .collect(Collectors.toMap(Question::getId, question -> question));

        int score = 0;
        // 遍历提交的答案，与正确答案比较
        for (ExamSubmission.Answer answer : submission.getAnswers()) {
            Question question = questionMap.get(answer.getQuestionId());
            if (question != null && question.getCorrect().equals(answer.getUserAnswer())) {
                // 假设每个问题的分值是从问题实体中获取，或者默认为1
                score += question.getScore();
            }
        }

        return score;
    }
}
