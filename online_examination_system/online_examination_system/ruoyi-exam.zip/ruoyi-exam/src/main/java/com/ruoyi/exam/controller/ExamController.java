package com.ruoyi.exam.controller;

import com.ruoyi.common.annotation.Anonymous;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.exam.domain.ExamSubmission;
import com.ruoyi.exam.service.ExamService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



@RestController
@RequestMapping("/exam")
public class ExamController {

    @Autowired
    private ExamService examService;

    @Anonymous
    @PostMapping("/submit")
    public AjaxResult submitExam(@RequestBody ExamSubmission submission) {
        int score = examService.calculateScore(submission);
        return AjaxResult.success("提交成功", score);
    }

}
