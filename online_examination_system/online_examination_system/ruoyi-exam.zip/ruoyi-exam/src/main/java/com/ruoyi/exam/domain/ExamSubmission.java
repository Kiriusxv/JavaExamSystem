package com.ruoyi.exam.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ExamSubmission {
    private List<Answer> answers;
    private List<Integer> subjectIds;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Answer {
        private Long questionId;
        private String userAnswer;
    }

}
