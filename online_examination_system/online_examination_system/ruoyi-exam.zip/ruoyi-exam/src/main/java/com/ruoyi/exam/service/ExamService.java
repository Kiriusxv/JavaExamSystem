package com.ruoyi.exam.service;


import com.ruoyi.exam.domain.ExamSubmission;

public interface ExamService {
    int calculateScore(ExamSubmission submission);
}
